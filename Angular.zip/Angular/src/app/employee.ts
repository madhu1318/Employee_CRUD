export class Employee {
  id: number | undefined;
  firstName: string | undefined;
  lastName: string | undefined;
  emailId: string | undefined;
  active: boolean | undefined;
}
